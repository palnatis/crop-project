from project.database import db


class StatisticsDao:
    """
        Class to represent data_statistics table
    """
    def __init__(self, station_id, year_from_date,
                 avg_max_temp, avg_min_temp, total_precipitation):
        self.station_id = station_id
        self.year_from_date = year_from_date
        self.avg_max_temp = avg_max_temp
        self.avg_min_temp = avg_min_temp
        self.total_precipitation = total_precipitation

    def __repr__(self):
        return 'StatisticsDao({0}, {1})'.format(self.station_id,
                                                self.year_from_date)

    def insert_record(self):
        """
        inserts record into datbase
        """
        cursor = db.cursor()
        sql = "INSERT INTO `data_statistics` (`station_id`, " \
              "`year_from_date`, `avg_max_temp`, `avg_min_temp`, " \
              "`total_precipitation`) VALUES (%s, %s, %s, %s, %s)"
        cursor.execute(sql, (self.station_id, self.year_from_date,
                             self.avg_max_temp, self.avg_min_temp,
                             self.total_precipitation))
        db.commit()

    @staticmethod
    def get_stats_data(page, limit):
        """
        Gets the corn yield data for the given page and limit
        :params
            page: Page number
            limit: Number of records
        :return:
            results(tuple): result from query
        """
        offset = (page - 1) * limit
        sql = f"select * from `data_statistics` limit {offset}, {limit}"
        cursor = db.cursor()
        cursor.execute(sql)
        results = cursor.fetchall()
        return results
