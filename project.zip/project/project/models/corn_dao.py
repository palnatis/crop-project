from project.database import db


class CornYieldDao:
    """
    Class to represent corn yield table
    """
    def __init__(self, year, corn_yield):
        self.year = year
        self.corn_yield = corn_yield

    def __repr__(self):
        return 'CornYieldDao({0}, {1})'.format(self.year, self.corn_yield)

    def insert_record(self):
        """
        inserts record into datbase
        """
        cursor = db.cursor()
        sql = "INSERT INTO `corn_yield` (`year`, `yield`) VALUES (%s, %s)"
        cursor.execute(sql, (self.year, self.corn_yield))
        db.commit()

    @staticmethod
    def get_corn_yield_data(page, limit):
        """
        Gets the corn yield data for the given page and limit
        :params
            page: Page number
            limit: Number of records
        :return:
            results(tuple): result from query
        """
        offset = (page - 1) * limit
        sql = f"select * from `corn_yield` limit {offset}, {limit}"
        cursor = db.cursor()
        cursor.execute(sql)
        results = cursor.fetchall()
        return results
