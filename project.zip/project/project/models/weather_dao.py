from project.database import db


class WeatherDao:
    """
    Class to represent weather table
    """
    def __init__(self, station_id, date, max_temperature,
                 min_temperature, precipitation):
        self.station_id = station_id
        self.date = date
        self.max_temperature = max_temperature
        self.min_temperature = min_temperature
        self.precipitation = precipitation

    def __repr__(self):
        return 'WeatherDao({0}, {1})'.format(self.station_id, self.date)

    def insert_record(self):
        """
        Inserts record into table
        """
        cursor = db.cursor()
        sql = "INSERT INTO `weather` (`station_id`, `date`, " \
              "`max_temperature`, `min_temperature`, " \
              "`precipitation`) VALUES (%s, %s, %s, %s, %s)"
        cursor.execute(sql, (self.station_id, self.date, self.max_temperature,
                             self.min_temperature, self.precipitation))
        db.commit()

    @staticmethod
    def get_weather_records(station_id, date, page, limit):
        """
        Gets the corn yield data for the given page and limit
        :params
            station_id: filter criteria
            date: filter criteria
            page: Page number
            limit: Number of records
        :return:
            results(tuple): result from query
        """
        offset = (page - 1) * limit
        sql = "select * from `weather`"
        if station_id and date:
            sql = f"select * from `weather` where " \
                  f"station_id='{station_id}' and date='{date}'"
        elif station_id:
            sql = f"select * from `weather` where station_id='{station_id}'"
        elif date:
            sql = f"select * from `weather` where date='{date}'"
        sql += f" limit {offset}, {limit}"
        cursor = db.cursor()
        cursor.execute(sql)
        results = cursor.fetchall()
        return results
